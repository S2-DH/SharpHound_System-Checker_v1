# ===================================================================
# SERVICE.ZIP ANALYSIS TEST - RUNS AUTOMATICALLY
# ===================================================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Service.zip Analysis Test" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$maxFiles = 10

# Auto-detect service account and build correct path
$serviceAccount = $null
$serviceNames = @("SHDelegator", "SharpHound", "BloodHoundEnterprise", "SharpHoundDelegator")

foreach ($svcName in $serviceNames) {
    $service = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
    if ($service) {
        $serviceAccount = $service.StartName
        Write-Host "[AUTO-DETECT] Found service: $svcName" -ForegroundColor Green
        Write-Host "[AUTO-DETECT] Service account: $serviceAccount" -ForegroundColor Green
        break
    }
}

# Build archive path based on service account
$archivePath = $null
$searchPaths = @()

if ($serviceAccount) {
    # Extract username from domain\user format
    $username = if ($serviceAccount -like "*\*") { 
        $serviceAccount.Split('\')[1] 
    } else { 
        $serviceAccount 
    }
    
    # Primary path: Service account's AppData\Roaming
    $searchPaths += "C:\Users\$username\AppData\Roaming\BloodHoundEnterprise\log_archive"
    $searchPaths += "C:\Users\$username\AppData\Local\BloodHoundEnterprise\log_archive"
}

# Fallback paths
$searchPaths += "C:\ProgramData\BloodHoundEnterprise\log_archive"
$searchPaths += "$env:APPDATA\BloodHoundEnterprise\log_archive"

# Find first valid path
foreach ($path in $searchPaths) {
    if (Test-Path $path) {
        $archivePath = $path
        Write-Host "[AUTO-DETECT] Found archive path: $archivePath" -ForegroundColor Green
        break
    }
}

Write-Host ""

Write-Host "LOG ARCHIVE ANALYSIS - Service Logs" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Cyan

if (-not (Test-Path $archivePath)) {
    Write-Host "Archive path not found: $archivePath" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Possible reasons:" -ForegroundColor Gray
    Write-Host "  - BloodHound Enterprise not installed" -ForegroundColor Gray
    Write-Host "  - Log archive not configured" -ForegroundColor Gray
    Write-Host "  - Different installation path" -ForegroundColor Gray
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " Test Complete" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    exit
}

Write-Host "Archive Path: $archivePath" -ForegroundColor Gray
Write-Host ""

# Find service.zip files
$zipFiles = Get-ChildItem -Path $archivePath -Filter "*service.zip" -File -ErrorAction SilentlyContinue |
            Sort-Object CreationTime -Descending |
            Select-Object -First $maxFiles

if ($zipFiles.Count -eq 0) {
    Write-Host "No service.zip files found in archive" -ForegroundColor Yellow
    Write-Host ""
    
    # Show what files ARE in the archive
    $allFiles = Get-ChildItem -Path $archivePath -File -ErrorAction SilentlyContinue | Select-Object -First 5
    if ($allFiles) {
        Write-Host "Files found in archive:" -ForegroundColor Gray
        foreach ($file in $allFiles) {
            Write-Host "  - $($file.Name) ($($file.CreationTime.ToString('yyyy-MM-dd')))" -ForegroundColor DarkGray
        }
    }
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " Test Complete" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    exit
}

Write-Host "Found $($zipFiles.Count) service.zip file(s)" -ForegroundColor Cyan
Write-Host ""

$fileNumber = 1

foreach ($zipFile in $zipFiles) {
    Write-Host "[$fileNumber] $($zipFile.Name) ($([Math]::Round($zipFile.Length / 1MB, 1)) MB) | $($zipFile.CreationTime.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Yellow
    
    try {
        # Load .NET assembly for ZIP handling
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        
        # Open ZIP file
        $zip = [System.IO.Compression.ZipFile]::OpenRead($zipFile.FullName)
        
        # Find service.log entry
        $logEntry = $zip.Entries | Where-Object { $_.Name -eq "service.log" } | Select-Object -First 1
        
        if ($logEntry) {
            # Extract to temp location
            $tempFile = [System.IO.Path]::GetTempFileName()
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($logEntry, $tempFile, $true)
            
            # Read log file
            $logLines = Get-Content $tempFile -ErrorAction SilentlyContinue
            
            # Count lines
            $totalLines = $logLines.Count
            
            # Find errors (case-insensitive)
            $errorLines = $logLines | Where-Object { 
                $_ -match '\bERROR\b|\bFATAL\b|\bEXCEPTION\b' 
            }
            
            # Find warnings (case-insensitive)
            $warningLines = $logLines | Where-Object { 
                $_ -match '\bWARN\b|\bWARNING\b' 
            }
            
            Write-Host "  service.log: $totalLines lines, $($errorLines.Count) errors, $($warningLines.Count) warnings" -ForegroundColor $(if ($errorLines.Count -gt 0) { "Yellow" } elseif ($warningLines.Count -gt 0) { "Cyan" } else { "Green" })
            
            if ($errorLines.Count -gt 0) {
                Write-Host ""
                Write-Host "  Errors Found:" -ForegroundColor Red
                
                # Show up to 5 errors per file
                $errorLines | Select-Object -First 5 | ForEach-Object {
                    $line = $_.Trim()
                    
                    # Try to extract timestamp if present
                    if ($line -match '(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
                        $timestamp = $Matches[1]
                        # Remove timestamp from line for cleaner display
                        $line = $line -replace '\[?\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\]?\s*', ''
                    }
                    else {
                        $timestamp = "Unknown time"
                    }
                    
                    # Truncate long lines
                    if ($line.Length -gt 100) {
                        $line = $line.Substring(0, 97) + "..."
                    }
                    
                    Write-Host "    [$timestamp] $line" -ForegroundColor Gray
                }
                
                if ($errorLines.Count -gt 5) {
                    Write-Host "    ... and $($errorLines.Count - 5) more errors" -ForegroundColor DarkGray
                }
            }
            
            if ($warningLines.Count -gt 0) {
                Write-Host ""
                Write-Host "  Warnings Found:" -ForegroundColor Yellow
                
                # Show up to 3 warnings per file
                $warningLines | Select-Object -First 3 | ForEach-Object {
                    $line = $_.Trim()
                    
                    # Try to extract timestamp if present
                    if ($line -match '(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
                        $timestamp = $Matches[1]
                        # Remove timestamp from line for cleaner display
                        $line = $line -replace '\[?\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\]?\s*', ''
                    }
                    else {
                        $timestamp = "Unknown time"
                    }
                    
                    # Truncate long lines
                    if ($line.Length -gt 100) {
                        $line = $line.Substring(0, 97) + "..."
                    }
                    
                    Write-Host "    [$timestamp] $line" -ForegroundColor DarkGray
                }
                
                if ($warningLines.Count -gt 3) {
                    Write-Host "    ... and $($warningLines.Count - 3) more warnings" -ForegroundColor DarkGray
                }
            }
            
            if ($errorLines.Count -eq 0 -and $warningLines.Count -eq 0) {
                Write-Host "  Status: No errors or warnings found" -ForegroundColor Green
            }
            
            # Clean up temp file
            Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        }
        else {
            Write-Host "  service.log not found in ZIP" -ForegroundColor Yellow
        }
        
        $zip.Dispose()
    }
    catch {
        Write-Host "  Error reading ZIP: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    Write-Host ""
    $fileNumber++
}

# Summary
Write-Host "Summary: Analyzed $($zipFiles.Count) service.zip file(s)" -ForegroundColor Cyan
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Test Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
