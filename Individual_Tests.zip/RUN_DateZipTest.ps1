# ===================================================================
# DATE.ZIP ANALYSIS TEST - RUNS AUTOMATICALLY
# ===================================================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Date.zip Analysis Test" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$maxFiles = 10

# Auto-detect service account and build correct path
$serviceAccount = $null
$serviceNames = @("SHDelegator", "SharpHound", "BloodHoundEnterprise", "SharpHoundDelegator")

foreach ($svcName in $serviceNames) {
    $service = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
    if ($service) {
        $serviceAccount = $service.StartName
        Write-Host "[AUTO-DETECT] Found service: $svcName" -ForegroundColor Green
        Write-Host "[AUTO-DETECT] Service account: $serviceAccount" -ForegroundColor Green
        break
    }
}

# Build archive path based on service account
$archivePath = $null
$searchPaths = @()

if ($serviceAccount) {
    # Extract username from domain\user format
    $username = if ($serviceAccount -like "*\*") { 
        $serviceAccount.Split('\')[1] 
    } else { 
        $serviceAccount 
    }
    
    # Primary path: Service account's AppData\Roaming
    $searchPaths += "C:\Users\$username\AppData\Roaming\BloodHoundEnterprise\log_archive"
    $searchPaths += "C:\Users\$username\AppData\Local\BloodHoundEnterprise\log_archive"
}

# Fallback paths
$searchPaths += "C:\ProgramData\BloodHoundEnterprise\log_archive"
$searchPaths += "$env:APPDATA\BloodHoundEnterprise\log_archive"

# Find first valid path
foreach ($path in $searchPaths) {
    if (Test-Path $path) {
        $archivePath = $path
        Write-Host "[AUTO-DETECT] Found archive path: $archivePath" -ForegroundColor Green
        break
    }
}

Write-Host ""

Write-Host "LOG ARCHIVE ANALYSIS - Collection Logs" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Cyan

if (-not (Test-Path $archivePath)) {
    Write-Host "Archive path not found: $archivePath" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " Test Complete" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    exit
}

# Find date-based ZIP files (format: YYYY-MM-DD-HH-MM-SS_XXXX.zip)
$zipFiles = Get-ChildItem -Path $archivePath -Filter "*.zip" -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^\d{4}-\d{2}-\d{2}-' } |
            Where-Object { $_.Name -notlike "*service*" } |
            Sort-Object CreationTime -Descending |
            Select-Object -First $maxFiles

if ($zipFiles.Count -eq 0) {
    Write-Host "No collection archive files found" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " Test Complete" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    exit
}

Write-Host "Found $($zipFiles.Count) collection archive file(s)" -ForegroundColor Cyan
Write-Host ""

$fileNumber = 1
$allFailedComputers = @{}

foreach ($zipFile in $zipFiles) {
    Write-Host "[$fileNumber] $($zipFile.Name) ($([Math]::Round($zipFile.Length / 1KB, 0)) KB) | $($zipFile.CreationTime.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Yellow
    
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        
        $zip = [System.IO.Compression.ZipFile]::OpenRead($zipFile.FullName)
        
        # Find run.log (with timestamp prefix: YYYY-MM-DD-HH-MM-SS_XXXX_run.log)
        $runLogEntry = $zip.Entries | Where-Object { $_.Name -like "*_run.log" } | Select-Object -First 1
        
        # Find compstatus.csv (with timestamp prefix: YYYY-MM-DD-HH-MM-SS_XXXX_compstatus.csv)
        $compStatusEntry = $zip.Entries | Where-Object { $_.Name -like "*_compstatus.csv" } | Select-Object -First 1
        
        # Process run.log
        if ($runLogEntry) {
            $tempFile = [System.IO.Path]::GetTempFileName()
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($runLogEntry, $tempFile, $true)
            
            $logLines = Get-Content $tempFile -ErrorAction SilentlyContinue
            $totalLines = $logLines.Count
            $errorLines = $logLines | Where-Object { $_ -match '\bERROR\b|\bFATAL\b|\bEXCEPTION\b' }
            $warningLines = $logLines | Where-Object { $_ -match '\bWARN\b|\bWARNING\b' }
            
            Write-Host "  run.log: $totalLines lines, $($errorLines.Count) errors, $($warningLines.Count) warnings" -ForegroundColor $(if ($errorLines.Count -gt 0) { "Yellow" } elseif ($warningLines.Count -gt 0) { "Cyan" } else { "Green" })
            
            if ($errorLines.Count -gt 0) {
                Write-Host ""
                Write-Host "  Errors:" -ForegroundColor Red
                $errorLines | Select-Object -First 3 | ForEach-Object {
                    $line = $_.Trim()
                    if ($line -match '(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
                        $timestamp = $Matches[1]
                        $line = $line -replace '\[?\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\]?\s*', ''
                    }
                    else {
                        $timestamp = "Unknown"
                    }
                    if ($line.Length -gt 80) { $line = $line.Substring(0, 77) + "..." }
                    Write-Host "    [$timestamp] $line" -ForegroundColor Gray
                }
            }
            
            if ($warningLines.Count -gt 0) {
                Write-Host ""
                Write-Host "  Warnings:" -ForegroundColor Yellow
                $warningLines | Select-Object -First 3 | ForEach-Object {
                    $line = $_.Trim()
                    if ($line -match '(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
                        $timestamp = $Matches[1]
                        $line = $line -replace '\[?\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\]?\s*', ''
                    }
                    else {
                        $timestamp = "Unknown"
                    }
                    if ($line.Length -gt 80) { $line = $line.Substring(0, 77) + "..." }
                    Write-Host "    [$timestamp] $line" -ForegroundColor DarkGray
                }
                if ($warningLines.Count -gt 3) {
                    Write-Host "    ... and $($warningLines.Count - 3) more warnings" -ForegroundColor DarkGray
                }
            }
            
            Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        }
        
        # Process compstatus.csv
        if ($compStatusEntry) {
            $tempFile = [System.IO.Path]::GetTempFileName()
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($compStatusEntry, $tempFile, $true)
            
            $csvData = Import-Csv $tempFile -ErrorAction SilentlyContinue
            
            if ($csvData) {
                $totalComputers = $csvData.Count
                $successfulComputers = ($csvData | Where-Object { $_.Status -eq "Success" -or $_.Status -eq "0" }).Count
                $failedComputers = $totalComputers - $successfulComputers
                $successRate = if ($totalComputers -gt 0) { [Math]::Round(($successfulComputers / $totalComputers) * 100, 1) } else { 0 }
                
                Write-Host ""
                Write-Host "  compstatus.csv: $totalComputers computers, $successfulComputers success ($successRate%), $failedComputers failed" -ForegroundColor $(if ($failedComputers -gt 0) { "Yellow" } else { "Green" })
                
                if ($failedComputers -gt 0) {
                    # Categorize failures
                    $categories = @{
                        "NETWORK ERRORS" = @()
                        "ACCESS DENIED" = @()
                        "TIMEOUT ERRORS" = @()
                        "MEMORY/RESOURCE ERRORS" = @()
                        "SMB/RPC ERRORS" = @()
                        "AUTHENTICATION ERRORS" = @()
                        "OTHER ERRORS" = @()
                    }
                    
                    $failedEntries = $csvData | Where-Object { $_.Status -ne "Success" -and $_.Status -ne "0" }
                    
                    foreach ($entry in $failedEntries) {
                        $computerName = $entry.ComputerName
                        $error = $entry.Error
                        $status = $entry.Status
                        $lastSeen = $entry.LastSeen
                        
                        # Categorize by error message
                        if ($error -match 'timeout|timed out|no response') {
                            $categories["TIMEOUT ERRORS"] += $entry
                        }
                        elseif ($error -match 'access denied|permission|unauthorized|0x80070005') {
                            $categories["ACCESS DENIED"] += $entry
                        }
                        elseif ($error -match 'network path|unreachable|0x80070035|cannot connect') {
                            $categories["NETWORK ERRORS"] += $entry
                        }
                        elseif ($error -match 'memory|out of memory|resource') {
                            $categories["MEMORY/RESOURCE ERRORS"] += $entry
                        }
                        elseif ($error -match 'smb|rpc|0x800706BA|0x800706BF') {
                            $categories["SMB/RPC ERRORS"] += $entry
                        }
                        elseif ($error -match 'kerberos|ntlm|authentication|logon') {
                            $categories["AUTHENTICATION ERRORS"] += $entry
                        }
                        else {
                            $categories["OTHER ERRORS"] += $entry
                        }
                        
                        # Track last contact
                        if (-not $allFailedComputers.ContainsKey($computerName)) {
                            $allFailedComputers[$computerName] = @{
                                LastContact = $lastSeen
                                Error = $error
                                CollectionDate = $zipFile.CreationTime
                            }
                        }
                    }
                    
                    Write-Host ""
                    Write-Host "  Failed Computers (by category):" -ForegroundColor Red
                    
                    foreach ($category in @("NETWORK ERRORS", "TIMEOUT ERRORS", "ACCESS DENIED", "MEMORY/RESOURCE ERRORS", "SMB/RPC ERRORS", "AUTHENTICATION ERRORS", "OTHER ERRORS")) {
                        $items = $categories[$category]
                        
                        if ($items.Count -gt 0) {
                            Write-Host ""
                            Write-Host "  $category ($($items.Count))" -ForegroundColor Yellow
                            
                            # Show first 3 from each category
                            $items | Select-Object -First 3 | ForEach-Object {
                                $computerName = $_.ComputerName
                                $error = $_.Error
                                $lastSeen = $_.LastSeen
                                
                                # Truncate error
                                if ($error.Length -gt 40) {
                                    $error = $error.Substring(0, 37) + "..."
                                }
                                
                                $line = "    $($computerName.PadRight(20)) | $error"
                                
                                if ($lastSeen) {
                                    $line += " | Last: $lastSeen"
                                }
                                
                                Write-Host $line -ForegroundColor Gray
                            }
                            
                            if ($items.Count -gt 3) {
                                Write-Host "    ... and $($items.Count - 3) more" -ForegroundColor DarkGray
                            }
                        }
                    }
                }
                else {
                    Write-Host "  Status: All computers successful" -ForegroundColor Green
                }
            }
            
            Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        }
        
        $zip.Dispose()
    }
    catch {
        Write-Host "  Error reading ZIP: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    Write-Host ""
    $fileNumber++
}

# Summary
Write-Host "Summary: Analyzed $($zipFiles.Count) collection archive file(s)" -ForegroundColor Cyan

if ($allFailedComputers.Count -gt 0) {
    Write-Host "Total unique failed computers across all collections: $($allFailedComputers.Count)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Test Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
