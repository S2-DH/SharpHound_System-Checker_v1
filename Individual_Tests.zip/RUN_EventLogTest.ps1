# ===================================================================
# EVENT LOG TEST - RUNS AUTOMATICALLY
# ===================================================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Event Log Analysis Test" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$maxEvents = 20

Write-Host "SERVICE EVENT LOG ANALYSIS" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Cyan
Write-Host "Last $maxEvents SHDelegator Events (All Event IDs)" -ForegroundColor Yellow
Write-Host ""

try {
    # Query for ALL SHDelegator events (not just specific IDs)
    $allEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'
        ProviderName = 'SHDelegator'
    } -MaxEvents $maxEvents -ErrorAction Stop
    
    if ($allEvents) {
        # Categorize events
        $jobSchedules = @()
        $startStopEvents = @()
        $otherErrors = @()
        
        foreach ($event in $allEvents) {
            if ($event.Id -eq 9001) {
                $jobSchedules += $event
            }
            elseif ($event.Id -eq 0) {
                $startStopEvents += $event
            }
            else {
                # All other event IDs (9005, etc.)
                $otherErrors += $event
            }
        }
        
        # Display Job Schedules (9001)
        if ($jobSchedules.Count -gt 0) {
            Write-Host "RUNNING JOB SCHEDULES (Event ID 9001)" -ForegroundColor Cyan
            Write-Host "-" * 80 -ForegroundColor DarkGray
            
            foreach ($event in $jobSchedules) {
                $timestamp = $event.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
                
                $levelText = switch ($event.Level) {
                    1 { "Critical" }
                    2 { "Error" }
                    3 { "Warn" }
                    4 { "Info" }
                    default { "Info" }
                }
                
                $message = $event.Message
                if ($message) {
                    $message = ($message -split "`n")[0].Trim()
                    if ($message.Length -gt 60) {
                        $message = $message.Substring(0, 57) + "..."
                    }
                }
                else {
                    $message = "(No message)"
                }
                
                # Extract Event Data
                $eventDataString = ""
                if ($event.Properties) {
                    $eventDataPairs = @()
                    $propertyNames = @(
                        'Duration', 'Objects', 'Status', 'Target', 'Method', 
                        'Computer', 'Error', 'Version', 'Account'
                    )
                    
                    for ($i = 0; $i -lt $event.Properties.Count; $i++) {
                        $value = $event.Properties[$i].Value
                        if ($value) {
                            if ($i -lt $propertyNames.Count) {
                                $propName = $propertyNames[$i]
                            }
                            else {
                                $propName = "Prop$i"
                            }
                            
                            $valueStr = $value.ToString().Trim()
                            if ($valueStr) {
                                $eventDataPairs += "$propName=$valueStr"
                            }
                        }
                    }
                    
                    if ($eventDataPairs.Count -gt 0) {
                        $eventDataString = $eventDataPairs -join ' '
                    }
                }
                
                $levelColor = switch ($levelText) {
                    "Critical" { "Red" }
                    "Error" { "Red" }
                    "Warn" { "Yellow" }
                    default { "Gray" }
                }
                
                $line = "[$timestamp] $($levelText.PadRight(5)) | $message"
                
                if ($eventDataString) {
                    $line += " | $eventDataString"
                }
                
                Write-Host $line -ForegroundColor $levelColor
            }
            
            Write-Host ""
        }
        
        # Display Start/Stop Events (0)
        if ($startStopEvents.Count -gt 0) {
            Write-Host "SERVICE START/STOP EVENTS (Event ID 0)" -ForegroundColor Cyan
            Write-Host "-" * 80 -ForegroundColor DarkGray
            
            foreach ($event in $startStopEvents) {
                $timestamp = $event.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
                
                $levelText = switch ($event.Level) {
                    1 { "Critical" }
                    2 { "Error" }
                    3 { "Warn" }
                    4 { "Info" }
                    default { "Info" }
                }
                
                $message = $event.Message
                if ($message) {
                    $message = ($message -split "`n")[0].Trim()
                    if ($message.Length -gt 60) {
                        $message = $message.Substring(0, 57) + "..."
                    }
                }
                else {
                    $message = "(No message)"
                }
                
                # Extract Event Data
                $eventDataString = ""
                if ($event.Properties) {
                    $eventDataPairs = @()
                    $propertyNames = @(
                        'Duration', 'Objects', 'Status', 'Target', 'Method', 
                        'Computer', 'Error', 'Version', 'Account'
                    )
                    
                    for ($i = 0; $i -lt $event.Properties.Count; $i++) {
                        $value = $event.Properties[$i].Value
                        if ($value) {
                            if ($i -lt $propertyNames.Count) {
                                $propName = $propertyNames[$i]
                            }
                            else {
                                $propName = "Prop$i"
                            }
                            
                            $valueStr = $value.ToString().Trim()
                            if ($valueStr) {
                                $eventDataPairs += "$propName=$valueStr"
                            }
                        }
                    }
                    
                    if ($eventDataPairs.Count -gt 0) {
                        $eventDataString = $eventDataPairs -join ' '
                    }
                }
                
                $levelColor = "Green"
                
                $line = "[$timestamp] $($levelText.PadRight(5)) | $message"
                
                if ($eventDataString) {
                    $line += " | $eventDataString"
                }
                
                Write-Host $line -ForegroundColor $levelColor
            }
            
            Write-Host ""
        }
        
        # Display Other Errors (9005 and others)
        if ($otherErrors.Count -gt 0) {
            Write-Host "OTHER ERRORS (Event IDs: $($otherErrors.Id | Select-Object -Unique | Sort-Object))" -ForegroundColor Cyan
            Write-Host "-" * 80 -ForegroundColor DarkGray
            
            foreach ($event in $otherErrors) {
                $timestamp = $event.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
                
                $levelText = switch ($event.Level) {
                    1 { "Critical" }
                    2 { "Error" }
                    3 { "Warn" }
                    4 { "Info" }
                    default { "Info" }
                }
                
                $eventId = $event.Id
                
                $message = $event.Message
                if ($message) {
                    $message = ($message -split "`n")[0].Trim()
                    if ($message.Length -gt 60) {
                        $message = $message.Substring(0, 57) + "..."
                    }
                }
                else {
                    $message = "(No message)"
                }
                
                # Extract Event Data
                $eventDataString = ""
                if ($event.Properties) {
                    $eventDataPairs = @()
                    $propertyNames = @(
                        'Duration', 'Objects', 'Status', 'Target', 'Method', 
                        'Computer', 'Error', 'Version', 'Account'
                    )
                    
                    for ($i = 0; $i -lt $event.Properties.Count; $i++) {
                        $value = $event.Properties[$i].Value
                        if ($value) {
                            if ($i -lt $propertyNames.Count) {
                                $propName = $propertyNames[$i]
                            }
                            else {
                                $propName = "Prop$i"
                            }
                            
                            $valueStr = $value.ToString().Trim()
                            if ($valueStr) {
                                $eventDataPairs += "$propName=$valueStr"
                            }
                        }
                    }
                    
                    if ($eventDataPairs.Count -gt 0) {
                        $eventDataString = $eventDataPairs -join ' '
                    }
                }
                
                $levelColor = switch ($levelText) {
                    "Critical" { "Red" }
                    "Error" { "Red" }
                    "Warn" { "Yellow" }
                    default { "Gray" }
                }
                
                $line = "[$timestamp] ID $($eventId.ToString().PadLeft(4)) $($levelText.PadRight(5)) | $message"
                
                if ($eventDataString) {
                    $line += " | $eventDataString"
                }
                
                Write-Host $line -ForegroundColor $levelColor
            }
            
            Write-Host ""
        }
        
        # ================================================================
        # gMSA AUTHENTICATION EVENTS (from Security log)
        # ================================================================
        
        Write-Host "gMSA AUTHENTICATION EVENTS (Last 10 from Security log)" -ForegroundColor Cyan
        Write-Host "-" * 80 -ForegroundColor DarkGray
        
        # Try to detect service account
        $serviceAccount = $null
        $serviceNames = @("SHDelegator", "SharpHound", "BloodHoundEnterprise", "SharpHoundDelegator")
        
        foreach ($svcName in $serviceNames) {
            $service = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
            if ($service) {
                $serviceAccount = $service.StartName
                break
            }
        }
        
        if ($serviceAccount) {
            # Extract just the account name (without domain)
            $accountName = if ($serviceAccount -like "*\*") {
                $serviceAccount.Split('\')[1]
            } else {
                $serviceAccount
            }
            
            try {
                # Query Security log for authentication events related to this account
                # Event IDs: 4624 (Logon), 4625 (Failed logon), 4768 (Kerberos TGT), 4771 (Kerberos pre-auth failed)
                $securityEvents = Get-WinEvent -FilterHashtable @{
                    LogName = 'Security'
                    ID = @(4624, 4625, 4768, 4771)
                } -MaxEvents 1000 -ErrorAction Stop | 
                Where-Object { $_.Message -like "*$accountName*" } |
                Select-Object -First 10
                
                if ($securityEvents) {
                    $authSuccess = 0
                    $authFailed = 0
                    
                    foreach ($event in $securityEvents) {
                        $timestamp = $event.TimeCreated.ToString("yyyy-MM-dd HH:mm:ss")
                        $eventId = $event.Id
                        
                        # Determine event type and color
                        $eventType = ""
                        $eventColor = "Gray"
                        
                        switch ($eventId) {
                            4624 { 
                                $eventType = "Successful Logon"
                                $eventColor = "Green"
                                $authSuccess++
                            }
                            4625 { 
                                $eventType = "Failed Logon"
                                $eventColor = "Red"
                                $authFailed++
                            }
                            4768 { 
                                $eventType = "Kerberos TGT Request"
                                $eventColor = "Cyan"
                                $authSuccess++
                            }
                            4771 { 
                                $eventType = "Kerberos Pre-Auth Failed"
                                $eventColor = "Red"
                                $authFailed++
                            }
                        }
                        
                        # Try to extract logon type for 4624 events
                        $logonType = ""
                        if ($eventId -eq 4624) {
                            if ($event.Message -match "Logon Type:\s+(\d+)") {
                                $logonTypeNum = $Matches[1]
                                $logonType = switch ($logonTypeNum) {
                                    "2" { "Interactive" }
                                    "3" { "Network" }
                                    "4" { "Batch" }
                                    "5" { "Service" }
                                    "7" { "Unlock" }
                                    "10" { "RemoteInteractive" }
                                    default { "Type $logonTypeNum" }
                                }
                                $logonType = " LogonType=$logonType"
                            }
                        }
                        
                        # Try to extract failure reason for 4625/4771
                        $failureReason = ""
                        if ($eventId -eq 4625 -or $eventId -eq 4771) {
                            if ($event.Message -match "Failure Reason:\s+(.+)") {
                                $failureReason = " Reason=$($Matches[1].Trim())"
                            }
                            elseif ($event.Message -match "Status:\s+(0x[0-9A-F]+)") {
                                $failureReason = " Status=$($Matches[1])"
                            }
                        }
                        
                        $line = "[$timestamp] ID $($eventId.ToString().PadLeft(4)) | $($eventType.PadRight(25)) | Account=$accountName$logonType$failureReason"
                        
                        Write-Host $line -ForegroundColor $eventColor
                    }
                    
                    Write-Host ""
                    Write-Host "gMSA Auth Summary: $authSuccess successful, $authFailed failed" -ForegroundColor $(if ($authFailed -gt 0) { "Yellow" } else { "Green" })
                    Write-Host ""
                }
                else {
                    Write-Host "No authentication events found for $serviceAccount in last 1000 Security log entries" -ForegroundColor Gray
                    Write-Host ""
                }
            }
            catch {
                Write-Host "Unable to read Security log (requires Administrator privileges)" -ForegroundColor Yellow
                Write-Host "Run as Administrator to view gMSA authentication events" -ForegroundColor Gray
                Write-Host ""
            }
        }
        else {
            Write-Host "Service account not detected - cannot filter authentication events" -ForegroundColor Gray
            Write-Host ""
        }
        
        # Summary
        $totalInfo = ($allEvents | Where-Object { $_.Level -eq 4 }).Count
        $totalWarn = ($allEvents | Where-Object { $_.Level -eq 3 }).Count
        $totalError = ($allEvents | Where-Object { $_.Level -in @(1,2) }).Count
        
        $summaryLine = "Summary: "
        $summaryLine += "Job Schedules=$($jobSchedules.Count), "
        $summaryLine += "Start/Stop=$($startStopEvents.Count), "
        $summaryLine += "Other Errors=$($otherErrors.Count) | "
        $summaryLine += "Total: $totalInfo Info"
        if ($totalWarn -gt 0) {
            $summaryLine += ", $totalWarn Warn"
        }
        if ($totalError -gt 0) {
            $summaryLine += ", $totalError Error"
            $lastError = ($allEvents | Where-Object { $_.Level -in @(1,2) } | Select-Object -First 1)
            if ($lastError) {
                $summaryLine += " | Last error: $($lastError.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'))"
            }
        }
        
        Write-Host $summaryLine -ForegroundColor Cyan
    }
    else {
        Write-Host "No SHDelegator events found" -ForegroundColor Yellow
    }
}
catch [System.Exception] {
    if ($_.Exception.Message -like "*No events were found*") {
        Write-Host "No SHDelegator events found in Application log" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Possible reasons:" -ForegroundColor Gray
        Write-Host "  - Service has not run yet" -ForegroundColor Gray
        Write-Host "  - Event log has been cleared" -ForegroundColor Gray
        Write-Host "  - Service is using different event source name" -ForegroundColor Gray
    }
    else {
        Write-Host "Error reading event logs: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Test Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
