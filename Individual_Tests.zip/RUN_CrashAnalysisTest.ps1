# ===================================================================
# WER CRASH ANALYSIS TEST - RUNS AUTOMATICALLY
# ===================================================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Crash Dump Analysis Test" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$maxReports = 10
$daysBack = 30

Write-Host "CRASH DUMP & ERROR REPORT ANALYSIS" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Cyan

$werPaths = @(
    "C:\ProgramData\Microsoft\Windows\WER\ReportQueue",
    "C:\ProgramData\Microsoft\Windows\WER\ReportArchive"
)

$crashes = @()
$cutoffDate = (Get-Date).AddDays(-$daysBack)

# Scan both ReportQueue and ReportArchive
foreach ($werPath in $werPaths) {
    if (Test-Path $werPath) {
        $folders = Get-ChildItem -Path $werPath -Directory -ErrorAction SilentlyContinue
        
        foreach ($folder in $folders) {
            # Look for SHDelegator or SharpHound related crashes
            if ($folder.Name -like "*SHDelegator*" -or $folder.Name -like "*SharpHound*") {
                
                # Check if within date range
                if ($folder.CreationTime -ge $cutoffDate) {
                    
                    # Parse folder name
                    $crashType = "Unknown"
                    $process = "Unknown"
                    
                    if ($folder.Name -match "^(AppCrash|AppHang)_(.+?)_") {
                        $crashType = $Matches[1]
                        $process = $Matches[2]
                    }
                    
                    # Try to read Report.wer file
                    $reportFile = Join-Path $folder.FullName "Report.wer"
                    $exception = ""
                    $faultModule = ""
                    $faultOffset = ""
                    $waitTime = ""
                    
                    if (Test-Path $reportFile) {
                        try {
                            $reportContent = Get-Content $reportFile -ErrorAction SilentlyContinue
                            
                            foreach ($line in $reportContent) {
                                if ($line -match "ExceptionCode=(.+)") {
                                    $exception = $Matches[1].Trim()
                                }
                                elseif ($line -match "FaultingModuleName=(.+)") {
                                    $faultModule = $Matches[1].Trim()
                                }
                                elseif ($line -match "FaultingModuleOffset=(.+)") {
                                    $faultOffset = $Matches[1].Trim()
                                }
                                elseif ($line -match "WaitTime=(.+)") {
                                    $waitTime = $Matches[1].Trim()
                                }
                            }
                        }
                        catch { }
                    }
                    
                    # Check for memory dump
                    $dumpFile = Get-ChildItem -Path $folder.FullName -Filter "*.mdmp" -ErrorAction SilentlyContinue | Select-Object -First 1
                    $dumpSize = if ($dumpFile) { 
                        [Math]::Round($dumpFile.Length / 1MB, 1)
                    } else { 
                        0 
                    }
                    
                    # Location
                    $location = if ($folder.FullName -like "*ReportQueue*") { "ReportQueue" } else { "ReportArchive" }
                    
                    $crashes += [PSCustomObject]@{
                        Timestamp = $folder.CreationTime
                        CrashType = $crashType
                        Process = $process
                        Exception = $exception
                        FaultModule = $faultModule
                        FaultOffset = $faultOffset
                        WaitTime = $waitTime
                        Location = $location
                        FolderName = $folder.Name
                        DumpSize = $dumpSize
                    }
                }
            }
        }
    }
}

if ($crashes.Count -eq 0) {
    Write-Host "Windows Error Reports - SHDelegator (Last $daysBack Days): 0 crashes found" -ForegroundColor Green
    Write-Host ""
    
    # Show last WER file to verify we're looking in the right place
    $lastQueueFile = $null
    $lastArchiveFile = $null
    
    if (Test-Path "C:\ProgramData\Microsoft\Windows\WER\ReportQueue") {
        $lastQueueFile = Get-ChildItem -Path "C:\ProgramData\Microsoft\Windows\WER\ReportQueue" -Directory -ErrorAction SilentlyContinue | 
                         Sort-Object CreationTime -Descending | 
                         Select-Object -First 1
    }
    
    if (Test-Path "C:\ProgramData\Microsoft\Windows\WER\ReportArchive") {
        $lastArchiveFile = Get-ChildItem -Path "C:\ProgramData\Microsoft\Windows\WER\ReportArchive" -Directory -ErrorAction SilentlyContinue | 
                           Sort-Object CreationTime -Descending | 
                           Select-Object -First 1
    }
    
    if ($lastQueueFile) {
        Write-Host "> Last WER report in ReportQueue: $($lastQueueFile.Name) from $($lastQueueFile.CreationTime.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Gray
    }
    else {
        Write-Host "> No files in ReportQueue" -ForegroundColor Gray
    }
    
    if ($lastArchiveFile) {
        Write-Host "> Last WER report in ReportArchive: $($lastArchiveFile.Name) from $($lastArchiveFile.CreationTime.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Gray
    }
    else {
        Write-Host "> No files in ReportArchive" -ForegroundColor Gray
    }
    
    Write-Host ""
    Write-Host "Status: [PASS] No crashes detected" -ForegroundColor Green
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " Test Complete" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    exit
}

# Sort and limit
$crashes = $crashes | Sort-Object Timestamp -Descending | Select-Object -First $maxReports

Write-Host "Windows Error Reports - SHDelegator (Last $daysBack Days): $($crashes.Count) crashes found" -ForegroundColor Yellow
Write-Host ""

# Categorize
$categorized = @{
    "ACCESS VIOLATIONS" = @()
    ".NET RUNTIME ERRORS" = @()
    "APPLICATION HANGS" = @()
    "CLR EXCEPTIONS" = @()
    "OTHER CRASHES" = @()
}

foreach ($crash in $crashes) {
    if ($crash.Exception -eq "0xC0000005" -or $crash.Exception -eq "c0000005") {
        $categorized["ACCESS VIOLATIONS"] += $crash
    }
    elseif ($crash.Exception -eq "0xE0434352" -or $crash.Exception -eq "e0434352") {
        $categorized[".NET RUNTIME ERRORS"] += $crash
    }
    elseif ($crash.Exception -eq "0x80131623" -or $crash.Exception -eq "80131623") {
        $categorized["CLR EXCEPTIONS"] += $crash
    }
    elseif ($crash.CrashType -eq "AppHang") {
        $categorized["APPLICATION HANGS"] += $crash
    }
    else {
        $categorized["OTHER CRASHES"] += $crash
    }
}

# Display
foreach ($category in @("ACCESS VIOLATIONS", ".NET RUNTIME ERRORS", "APPLICATION HANGS", "CLR EXCEPTIONS", "OTHER CRASHES")) {
    $items = $categorized[$category]
    
    if ($items.Count -gt 0) {
        Write-Host "$category ($($items.Count) $(if ($items.Count -eq 1) { 'crash' } else { 'crashes' }))" -ForegroundColor Yellow
        
        foreach ($crash in $items) {
            $timestamp = $crash.Timestamp.ToString("yyyy-MM-dd HH:mm")
            
            $line = "  [$timestamp] $($crash.CrashType)"
            
            if ($crash.Exception) {
                $exceptionName = switch ($crash.Exception) {
                    "0xC0000005" { "0xC0000005 (Access Violation)" }
                    "0xE0434352" { "0xE0434352 (.NET Runtime)" }
                    "0x80131623" { "0x80131623 (CLR Exception)" }
                    default { $crash.Exception }
                }
                $line += " $exceptionName"
            }
            
            if ($crash.FaultModule) {
                $line += " | Module=$($crash.FaultModule)"
                if ($crash.FaultOffset) {
                    $line += " Offset=$($crash.FaultOffset)"
                }
            }
            
            if ($crash.WaitTime) {
                $waitSeconds = [int]$crash.WaitTime / 1000
                $line += " | Wait=$($waitSeconds)s"
            }
            
            $line += " | $($crash.Location)\$($crash.FolderName.Substring(0, [Math]::Min(20, $crash.FolderName.Length)))..."
            
            Write-Host $line -ForegroundColor Gray
        }
        
        Write-Host ""
    }
}

# Summary
$mostCommonType = ($categorized.GetEnumerator() | Where-Object { $_.Value.Count -gt 0 } | Sort-Object { $_.Value.Count } -Descending | Select-Object -First 1)
if ($mostCommonType) {
    $percentage = [Math]::Round(($mostCommonType.Value.Count / $crashes.Count) * 100, 0)
    Write-Host "Status: [WARN] $($crashes.Count) crashes in $daysBack days - most common: $($mostCommonType.Key) ($percentage%)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Test Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
