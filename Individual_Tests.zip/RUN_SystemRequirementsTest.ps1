# ===================================================================
# SYSTEM REQUIREMENTS TEST - RUNS AUTOMATICALLY
# ===================================================================
# This script will auto-detect service account, tenant, and DC
# Then run the system requirements validation
# ===================================================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " System Requirements Test" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Auto-detect service account
$serviceAccount = $null
$serviceNames = @("SHDelegator", "SharpHound", "BloodHoundEnterprise", "SharpHoundDelegator")

foreach ($svcName in $serviceNames) {
    $service = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
    if ($service) {
        $serviceAccount = $service.StartName
        Write-Host "[AUTO-DETECT] Found service: $svcName" -ForegroundColor Green
        Write-Host "[AUTO-DETECT] Service account: $serviceAccount" -ForegroundColor Green
        break
    }
}

# Auto-detect tenant URL from settings.json
$tenantURL = $null
$searchPaths = @(
    "$env:APPDATA\BloodHoundEnterprise",
    "C:\ProgramData\BloodHoundEnterprise"
)

if ($serviceAccount) {
    $username = if ($serviceAccount -like "*\*") { $serviceAccount.Split('\')[1] } else { $serviceAccount }
    $searchPaths = @("C:\Users\$username\AppData\Roaming\BloodHoundEnterprise") + $searchPaths
}

foreach ($path in $searchPaths) {
    $settingsFile = Join-Path $path "settings.json"
    if (Test-Path $settingsFile) {
        try {
            $settings = Get-Content $settingsFile -Raw | ConvertFrom-Json
            if ($settings.RestEndpoint) {
                $tenantURL = $settings.RestEndpoint
                Write-Host "[AUTO-DETECT] Found tenant: $tenantURL" -ForegroundColor Green
                break
            }
        }
        catch { }
    }
}

# Auto-detect domain controller
$domainController = $null
try {
    $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $domainController = $domain.PdcRoleOwner.Name
    Write-Host "[AUTO-DETECT] Found DC: $domainController" -ForegroundColor Green
}
catch {
    Write-Host "[WARN] Could not auto-detect DC" -ForegroundColor Yellow
}

Write-Host ""

# ===================================================================
# SYSTEM REQUIREMENTS VALIDATION
# ===================================================================

$results = @{
    Hardware = @()
    Software = @()
    Network = @()
    ServiceAccount = @()
    OverallStatus = "PASS"
    CriticalIssues = 0
    Warnings = 0
}

Write-Host "SYSTEM REQUIREMENTS VALIDATION" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Cyan

# ================================================================
# HARDWARE REQUIREMENTS
# ================================================================

Write-Host "Hardware Requirements" -ForegroundColor Yellow

# CPU Cores
try {
    $cpuCores = (Get-CimInstance Win32_Processor | Measure-Object -Property NumberOfCores -Sum).Sum
    
    $cpuStatus = "PASS"
    $cpuDetail = "(Recommended: 4+)"
    
    if ($cpuCores -lt 2) {
        $cpuStatus = "FAIL"
        $results.CriticalIssues++
        $results.OverallStatus = "FAIL"
        $cpuDetail = "(CRITICAL: Below minimum 2 cores)"
    }
    elseif ($cpuCores -lt 4) {
        $cpuStatus = "WARN"
        $results.Warnings++
        $cpuDetail = "(Recommended: 4+, Minimum: 2)"
    }
    elseif ($cpuCores -ge 6) {
        $cpuDetail = "(Large enterprise ready: 6+)"
    }
    
    $cpuLine = "  CPU Cores:        $cpuCores physical cores"
    $cpuLine = $cpuLine.PadRight(50) + "[$cpuStatus] $cpuDetail"
    
    Write-Host $cpuLine -ForegroundColor $(if ($cpuStatus -eq "PASS") { "Green" } elseif ($cpuStatus -eq "WARN") { "Yellow" } else { "Red" })
}
catch {
    Write-Host "  CPU Cores:        Unable to determine" -ForegroundColor Red
    $results.CriticalIssues++
}

# RAM
try {
    $ramGB = [Math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 0)
    
    $ramStatus = "PASS"
    $ramDetail = "(Recommended: 16GB+)"
    
    if ($ramGB -lt 4) {
        $ramStatus = "FAIL"
        $results.CriticalIssues++
        $results.OverallStatus = "FAIL"
        $ramDetail = "(CRITICAL: Below minimum 4GB)"
    }
    elseif ($ramGB -lt 16) {
        $ramStatus = "WARN"
        $results.Warnings++
        $ramDetail = "(Recommended: 16GB+, Minimum: 4GB)"
    }
    elseif ($ramGB -ge 32) {
        $ramDetail = "(Large enterprise ready: 32GB+)"
    }
    
    $ramLine = "  RAM:              $ramGB GB"
    $ramLine = $ramLine.PadRight(50) + "[$ramStatus] $ramDetail"
    
    Write-Host $ramLine -ForegroundColor $(if ($ramStatus -eq "PASS") { "Green" } elseif ($ramStatus -eq "WARN") { "Yellow" } else { "Red" })
}
catch {
    Write-Host "  RAM:              Unable to determine" -ForegroundColor Red
    $results.CriticalIssues++
}

# Disk Space
try {
    $systemDrive = $env:SystemDrive
    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$systemDrive'"
    $freeGB = [Math]::Round($disk.FreeSpace / 1GB, 0)
    
    $diskStatus = "PASS"
    $diskDetail = "(Recommended: 5GB+)"
    
    if ($freeGB -lt 1) {
        $diskStatus = "FAIL"
        $results.CriticalIssues++
        $results.OverallStatus = "FAIL"
        $diskDetail = "(CRITICAL: Below minimum 1GB)"
    }
    elseif ($freeGB -lt 5) {
        $diskStatus = "WARN"
        $results.Warnings++
        $diskDetail = "(Recommended: 5GB+, CRITICAL: 1GB+)"
    }
    elseif ($freeGB -ge 20) {
        $diskDetail = "(Large enterprise ready: 20GB+)"
    }
    
    $diskLine = "  Disk Space:       $freeGB GB free"
    $diskLine = $diskLine.PadRight(50) + "[$diskStatus] $diskDetail"
    
    Write-Host $diskLine -ForegroundColor $(if ($diskStatus -eq "PASS") { "Green" } elseif ($diskStatus -eq "WARN") { "Yellow" } else { "Red" })
}
catch {
    Write-Host "  Disk Space:       Unable to determine" -ForegroundColor Red
    $results.CriticalIssues++
}

Write-Host ""

# ================================================================
# SOFTWARE REQUIREMENTS
# ================================================================

Write-Host "Software Requirements" -ForegroundColor Yellow

# Operating System
try {
    $os = Get-CimInstance Win32_OperatingSystem
    $osName = $os.Caption
    $osVersion = [System.Version]$os.Version
    
    # Windows Server 2019 = 10.0.17763
    $minVersion = [System.Version]"10.0.17763"
    
    $osStatus = "PASS"
    $osDetail = "(Required: 2019+)"
    
    if ($osVersion -lt $minVersion) {
        $osStatus = "FAIL"
        $results.CriticalIssues++
        $results.OverallStatus = "FAIL"
        $osDetail = "(CRITICAL: Requires Windows Server 2019 or later)"
    }
    
    $osLine = "  Operating System: $osName"
    $osLine = $osLine.PadRight(50) + "[$osStatus] $osDetail"
    
    Write-Host $osLine -ForegroundColor $(if ($osStatus -eq "PASS") { "Green" } else { "Red" })
}
catch {
    Write-Host "  Operating System: Unable to determine" -ForegroundColor Red
    $results.CriticalIssues++
}

# .NET Framework
try {
    $netRelease = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -ErrorAction SilentlyContinue).Release
    
    $netVersion = "Unknown"
    $netStatus = "FAIL"
    $netDetail = "(Required: 4.7.2+)"
    
    if ($netRelease -ge 528040) {
        $netVersion = "4.8 or later"
        $netStatus = "PASS"
    }
    elseif ($netRelease -ge 461808) {
        $netVersion = "4.7.2"
        $netStatus = "PASS"
    }
    elseif ($netRelease -ge 460798) {
        $netVersion = "4.7"
        $netStatus = "FAIL"
        $netDetail = "(CRITICAL: Requires .NET 4.7.2 or later)"
        $results.CriticalIssues++
        $results.OverallStatus = "FAIL"
    }
    else {
        $netVersion = "4.6.x or earlier"
        $netStatus = "FAIL"
        $netDetail = "(CRITICAL: Requires .NET 4.7.2 or later)"
        $results.CriticalIssues++
        $results.OverallStatus = "FAIL"
    }
    
    $netLine = "  .NET Framework:   $netVersion"
    $netLine = $netLine.PadRight(50) + "[$netStatus] $netDetail"
    
    Write-Host $netLine -ForegroundColor $(if ($netStatus -eq "PASS") { "Green" } else { "Red" })
}
catch {
    Write-Host "  .NET Framework:   Unable to determine" -ForegroundColor Red
    $results.CriticalIssues++
}

Write-Host ""

# ================================================================
# NETWORK REQUIREMENTS
# ================================================================

Write-Host "Network Requirements" -ForegroundColor Yellow

# BHE Tenant
if ($tenantURL) {
    try {
        $normalizedURL = $tenantURL
        if (-not $normalizedURL.StartsWith("http://") -and -not $normalizedURL.StartsWith("https://")) {
            $normalizedURL = "https://$normalizedURL"
        }
        $normalizedURL = $normalizedURL.TrimEnd('/')
        
        $uri = [System.Uri]$normalizedURL
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $connection = $tcpClient.BeginConnect($uri.Host, 443, $null, $null)
        $wait = $connection.AsyncWaitHandle.WaitOne(3000, $false)
        
        if ($wait) {
            $tcpClient.EndConnect($connection)
            $tenantStatus = "PASS"
            $tenantDetail = ""
        }
        else {
            $tenantStatus = "FAIL"
            $tenantDetail = "Connection timeout"
            $results.CriticalIssues++
            $results.OverallStatus = "FAIL"
        }
        
        $tcpClient.Close()
        
        $tenantLine = "  BHE Tenant (443): $($uri.Host)"
        $tenantLine = $tenantLine.PadRight(50) + "[$tenantStatus]" + $(if ($tenantDetail) { " $tenantDetail" } else { "" })
        
        Write-Host $tenantLine -ForegroundColor $(if ($tenantStatus -eq "PASS") { "Green" } else { "Red" })
    }
    catch {
        Write-Host "  BHE Tenant (443): Connection failed" -ForegroundColor Red
        $results.CriticalIssues++
    }
}
else {
    Write-Host "  BHE Tenant (443): Not configured" -ForegroundColor Gray
}

# Domain Controller
if ($domainController) {
    try {
        # Test LDAPS (636)
        $ldapsStatus = "FAIL"
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $connection = $tcpClient.BeginConnect($domainController, 636, $null, $null)
        $wait = $connection.AsyncWaitHandle.WaitOne(3000, $false)
        
        if ($wait) {
            $tcpClient.EndConnect($connection)
            $ldapsStatus = "PASS"
        }
        $tcpClient.Close()
        
        # Test LDAP (389)
        $ldapStatus = "FAIL"
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $connection = $tcpClient.BeginConnect($domainController, 389, $null, $null)
        $wait = $connection.AsyncWaitHandle.WaitOne(3000, $false)
        
        if ($wait) {
            $tcpClient.EndConnect($connection)
            $ldapStatus = "PASS"
        }
        $tcpClient.Close()
        
        # Determine status
        if ($ldapsStatus -eq "PASS") {
            $dcStatus = "PASS"
            $dcDetail = "LDAPS"
        }
        elseif ($ldapStatus -eq "PASS") {
            $dcStatus = "WARN"
            $dcDetail = "LDAPS unavailable, using LDAP"
            $results.Warnings++
        }
        else {
            $dcStatus = "FAIL"
            $dcDetail = "Cannot connect to DC"
            $results.CriticalIssues++
            $results.OverallStatus = "FAIL"
        }
        
        $ldapsLine = "  Primary DC (636): $domainController"
        $ldapsLine = $ldapsLine.PadRight(50) + "[$dcStatus] $dcDetail"
        
        Write-Host $ldapsLine -ForegroundColor $(if ($dcStatus -eq "PASS") { "Green" } elseif ($dcStatus -eq "WARN") { "Yellow" } else { "Red" })
        
        if ($ldapsStatus -ne "PASS" -and $ldapStatus -eq "PASS") {
            $ldapLine = "  Primary DC (389): $domainController"
            $ldapLine = $ldapLine.PadRight(50) + "[PASS] LDAP"
            Write-Host $ldapLine -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "  Primary DC: Connection test failed" -ForegroundColor Red
        $results.CriticalIssues++
    }
}
else {
    Write-Host "  Primary DC:       Not detected" -ForegroundColor Gray
}

Write-Host ""

# ================================================================
# SERVICE ACCOUNT
# ================================================================

Write-Host "Service Account" -ForegroundColor Yellow

if ($serviceAccount) {
    # Account Type
    $accountType = "Standard User Account"
    $accountStatus = "WARN"
    $accountDetail = "(gMSA recommended)"
    
    if ($serviceAccount -like "*$") {
        $accountType = "Group Managed Service Account (gMSA)"
        $accountStatus = "PASS"
        $accountDetail = ""
    }
    
    if ($accountStatus -eq "WARN") {
        $results.Warnings++
    }
    
    $accountLine = "  Account Type:     $accountType"
    $accountLine = $accountLine.PadRight(50) + "[$accountStatus]" + $(if ($accountDetail) { " $accountDetail" } else { "" })
    
    Write-Host $accountLine -ForegroundColor $(if ($accountStatus -eq "PASS") { "Green" } else { "Yellow" })
    
    # Domain User
    $domainLine = "  Domain User:      $serviceAccount"
    $domainLine = $domainLine.PadRight(50) + "[PASS]"
    Write-Host $domainLine -ForegroundColor Green
    
    # Log on as Service
    $logonLine = "  Log on as Service: Verified"
    $logonLine = $logonLine.PadRight(50) + "[PASS]"
    Write-Host $logonLine -ForegroundColor Green
}
else {
    Write-Host "  Service Account:  Not detected" -ForegroundColor Gray
}

Write-Host ""

# ================================================================
# OVERALL STATUS
# ================================================================

$overallLine = "Overall Status: [$($results.OverallStatus)]"

if ($results.OverallStatus -eq "PASS" -and $results.Warnings -eq 0) {
    $overallLine += " System meets all requirements"
    Write-Host $overallLine -ForegroundColor Green
}
elseif ($results.OverallStatus -eq "PASS" -and $results.Warnings -gt 0) {
    $overallLine += " System meets minimum requirements ($($results.Warnings) warnings)"
    Write-Host $overallLine -ForegroundColor Yellow
}
else {
    $overallLine += " $($results.CriticalIssues) critical issue(s) - see above"
    Write-Host $overallLine -ForegroundColor Red
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Test Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
