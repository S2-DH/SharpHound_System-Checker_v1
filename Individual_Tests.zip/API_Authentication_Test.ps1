# ===================================================================
# API Authentication Fix - Standalone Test
# ===================================================================
# This script isolates and tests ONLY the API authentication
# Use this to verify the fix works before integrating into full script
# ===================================================================

param(
    [string]$SettingsPath,
    [string]$AuthPath,
    [string]$ServiceAccount  # Optional: manually specify service account (e.g., "states\t0_gMSA_SHSA$")
)

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " API Authentication Fix - Test" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ===================================================================
# AUTO-DETECT SERVICE ACCOUNT AND CONFIG FILES
# ===================================================================

# First, try to detect the service and get the service account
$detectedServiceAccount = $null

# Use manual ServiceAccount parameter if provided
if ($ServiceAccount) {
    $detectedServiceAccount = $ServiceAccount
    Write-Host "[MANUAL] Using service account: $ServiceAccount" -ForegroundColor Cyan
}
else {
    # Auto-detect from service
    $serviceNames = @("SHDelegator", "SharpHound", "BloodHoundEnterprise", "SharpHoundDelegator")
    
    foreach ($svcName in $serviceNames) {
        $service = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if ($service) {
            $detectedServiceAccount = $service.StartName
            Write-Host "[AUTO-DETECT] Found service: $svcName" -ForegroundColor Green
            Write-Host "[AUTO-DETECT] Service account: $detectedServiceAccount" -ForegroundColor Green
            break
        }
    }
}

if (-not $SettingsPath) {
    $searchPaths = @()
    
    # If we found a service account, check its profile FIRST
    if ($detectedServiceAccount) {
        # Extract username from DOMAIN\username format
        $username = if ($detectedServiceAccount -like "*\*") {
            $detectedServiceAccount.Split('\')[1]
        } else {
            $detectedServiceAccount
        }
        
        # Add service account profile paths at the beginning
        $searchPaths += "C:\Users\$username\AppData\Roaming\BloodHoundEnterprise"
        $searchPaths += "C:\Users\$username\AppData\Local\BloodHoundEnterprise"
    }
    
    # Then check common locations
    $searchPaths += "C:\ProgramData\BloodHoundEnterprise"
    $searchPaths += "$env:APPDATA\BloodHoundEnterprise"
    $searchPaths += "$env:USERPROFILE\AppData\Roaming\BloodHoundEnterprise"
    
    foreach ($path in $searchPaths) {
        $candidate = Join-Path $path "settings.json"
        if (Test-Path $candidate) {
            $SettingsPath = $candidate
            Write-Host "[AUTO-DETECT] Found settings.json: $SettingsPath" -ForegroundColor Green
            break
        }
    }
}

if (-not $AuthPath) {
    $searchPaths = @()
    
    # If we found a service account, check its profile FIRST
    if ($detectedServiceAccount) {
        # Extract username from DOMAIN\username format
        $username = if ($detectedServiceAccount -like "*\*") {
            $detectedServiceAccount.Split('\')[1]
        } else {
            $detectedServiceAccount
        }
        
        # Add service account profile paths at the beginning
        $searchPaths += "C:\Users\$username\AppData\Roaming\BloodHoundEnterprise"
        $searchPaths += "C:\Users\$username\AppData\Local\BloodHoundEnterprise"
    }
    
    # Then check common locations
    $searchPaths += "C:\ProgramData\BloodHoundEnterprise"
    $searchPaths += "$env:APPDATA\BloodHoundEnterprise"
    $searchPaths += "$env:USERPROFILE\AppData\Roaming\BloodHoundEnterprise"
    
    foreach ($path in $searchPaths) {
        $candidate = Join-Path $path "auth.json"
        if (Test-Path $candidate) {
            $AuthPath = $candidate
            Write-Host "[AUTO-DETECT] Found auth.json: $AuthPath" -ForegroundColor Green
            break
        }
    }
}

# Verify we found both files
if (-not $SettingsPath -or -not (Test-Path $SettingsPath)) {
    Write-Host ""
    Write-Host "[ERROR] Could not find settings.json" -ForegroundColor Red
    Write-Host ""
    Write-Host "Searched locations:" -ForegroundColor Yellow
    if ($detectedServiceAccount) {
        $username = if ($detectedServiceAccount -like "*\*") { $detectedServiceAccount.Split('\')[1] } else { $detectedServiceAccount }
        Write-Host "  - C:\Users\$username\AppData\Roaming\BloodHoundEnterprise" -ForegroundColor Gray
        Write-Host "  - C:\Users\$username\AppData\Local\BloodHoundEnterprise" -ForegroundColor Gray
    }
    Write-Host "  - C:\ProgramData\BloodHoundEnterprise" -ForegroundColor Gray
    Write-Host "  - $env:APPDATA\BloodHoundEnterprise" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Manually specify: .\Fix_API_Authentication_Test.ps1 -SettingsPath 'C:\Path\To\settings.json'" -ForegroundColor Cyan
    exit 1
}

if (-not $AuthPath -or -not (Test-Path $AuthPath)) {
    Write-Host ""
    Write-Host "[ERROR] Could not find auth.json" -ForegroundColor Red
    Write-Host ""
    Write-Host "Searched locations:" -ForegroundColor Yellow
    if ($detectedServiceAccount) {
        $username = if ($detectedServiceAccount -like "*\*") { $detectedServiceAccount.Split('\')[1] } else { $detectedServiceAccount }
        Write-Host "  - C:\Users\$username\AppData\Roaming\BloodHoundEnterprise" -ForegroundColor Gray
        Write-Host "  - C:\Users\$username\AppData\Local\BloodHoundEnterprise" -ForegroundColor Gray
    }
    Write-Host "  - C:\ProgramData\BloodHoundEnterprise" -ForegroundColor Gray
    Write-Host "  - $env:APPDATA\BloodHoundEnterprise" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Manually specify: .\Fix_API_Authentication_Test.ps1 -AuthPath 'C:\Path\To\auth.json'" -ForegroundColor Cyan
    exit 1
}

Write-Host ""

# ===================================================================
# READ SETTINGS.JSON
# ===================================================================

Write-Host "STEP 1: Reading settings.json" -ForegroundColor Yellow
Write-Host "  Path: $SettingsPath"

if (-not (Test-Path $SettingsPath)) {
    Write-Host "  [FAIL] settings.json not found" -ForegroundColor Red
    exit 1
}

try {
    $settingsData = Get-Content $SettingsPath -Raw | ConvertFrom-Json
    Write-Host "  [PASS] Valid JSON" -ForegroundColor Green
    
    if ($settingsData.RestEndpoint) {
        $restEndpoint = $settingsData.RestEndpoint
        Write-Host "  [PASS] RestEndpoint found: $restEndpoint" -ForegroundColor Green
    }
    else {
        Write-Host "  [FAIL] RestEndpoint not found in settings.json" -ForegroundColor Red
        Write-Host "  Expected property: 'RestEndpoint' (capitalized)" -ForegroundColor Yellow
        exit 1
    }
}
catch {
    Write-Host "  [FAIL] Invalid JSON: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""

# ===================================================================
# READ AUTH.JSON
# ===================================================================

Write-Host "STEP 2: Reading auth.json" -ForegroundColor Yellow
Write-Host "  Path: $AuthPath"

if (-not (Test-Path $AuthPath)) {
    Write-Host "  [FAIL] auth.json not found" -ForegroundColor Red
    exit 1
}

try {
    $authData = Get-Content $AuthPath -Raw | ConvertFrom-Json
    Write-Host "  [PASS] Valid JSON" -ForegroundColor Green
    
    # Check for TokenID (CAPITALIZED first, then lowercase fallback)
    if ($authData.TokenID) {
        $tokenId = $authData.TokenID
        Write-Host "  [PASS] TokenID found (property: 'TokenID'): $($tokenId.Substring(0,8))..." -ForegroundColor Green
    }
    elseif ($authData.id) {
        $tokenId = $authData.id
        Write-Host "  [PASS] TokenID found (property: 'id'): $($tokenId.Substring(0,8))..." -ForegroundColor Green
    }
    else {
        Write-Host "  [FAIL] TokenID not found (checked 'TokenID' and 'id' properties)" -ForegroundColor Red
        exit 1
    }
    
    # Check for Token (CAPITALIZED first, then lowercase fallback)
    if ($authData.Token) {
        $tokenKey = $authData.Token
        Write-Host "  [PASS] Token found (property: 'Token'): ***hidden***" -ForegroundColor Green
    }
    elseif ($authData.key) {
        $tokenKey = $authData.key
        Write-Host "  [PASS] Token found (property: 'key'): ***hidden***" -ForegroundColor Green
    }
    else {
        Write-Host "  [FAIL] Token not found (checked 'Token' and 'key' properties)" -ForegroundColor Red
        exit 1
    }
}
catch {
    Write-Host "  [FAIL] Invalid JSON: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""

# ===================================================================
# NORMALIZE URL
# ===================================================================

Write-Host "STEP 3: Normalizing URL" -ForegroundColor Yellow
Write-Host "  Original: $restEndpoint"

# Add https:// if not present (EXACT from Test-BHE-HMAC.ps1)
if (-not $restEndpoint.StartsWith("http://") -and -not $restEndpoint.StartsWith("https://")) {
    $restEndpoint = "https://$restEndpoint"
    Write-Host "  [INFO] Added https:// prefix" -ForegroundColor Cyan
}

# Remove trailing slash
$restEndpoint = $restEndpoint.TrimEnd('/')

Write-Host "  Normalized: $restEndpoint" -ForegroundColor Green
Write-Host ""

# ===================================================================
# HMAC SIGNATURE FUNCTION (EXACT FROM TEST-BHE-HMAC.PS1)
# ===================================================================

function Get-BHEHMACSignature {
    param(
        [string]$TokenId,
        [string]$TokenKey,
        [string]$Method,
        [string]$Uri
    )
    
    try {
        # Parse URI to get path and query
        $uriObj = [System.Uri]$Uri
        $endpoint = $uriObj.PathAndQuery
        
        # Generate timestamp: 2026-02-04T17:30:00+00:00
        $timestamp = [DateTime]::UtcNow.ToString("yyyy-MM-ddTHH:mm:ss+00:00")
        
        # DateKey is first 13 characters (e.g., "2026-02-04T17")
        $dateKey = $timestamp.Substring(0, 13)
        
        # Step 1: HMAC(token_key, METHOD+ENDPOINT)
        $hmac1 = New-Object System.Security.Cryptography.HMACSHA256
        $hmac1.Key = [System.Text.Encoding]::UTF8.GetBytes($TokenKey)
        $step1Input = "$Method$endpoint"
        $hash1 = $hmac1.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($step1Input))
        
        # Step 2: HMAC(hash1, DateKey)
        $hmac2 = New-Object System.Security.Cryptography.HMACSHA256
        $hmac2.Key = $hash1
        $hash2 = $hmac2.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($dateKey))
        
        # Step 3: HMAC(hash2, empty body)
        $hmac3 = New-Object System.Security.Cryptography.HMACSHA256
        $hmac3.Key = $hash2
        $hash3 = $hmac3.ComputeHash([System.Text.Encoding]::UTF8.GetBytes(""))
        
        # Base64 encode final hash
        $signature = [System.Convert]::ToBase64String($hash3)
        
        # Return headers with signature
        return @{
            "Authorization" = "bhesignature $TokenId"
            "RequestDate" = $timestamp
            "Signature" = $signature
            "Content-Type" = "application/json"
        }
    }
    catch {
        Write-Host "  [ERROR] HMAC generation failed: $_" -ForegroundColor Red
        return $null
    }
}

# ===================================================================
# TEST /API/V2/SELF (WITH HMAC AUTH)
# ===================================================================

Write-Host "STEP 4: Testing /api/v2/self (with HMAC auth)" -ForegroundColor Yellow

$selfUrl = "$restEndpoint/api/v2/self"
Write-Host "  URL: $selfUrl"
Write-Host "  Generating HMAC signature..."

$headers = Get-BHEHMACSignature -TokenId $tokenId -TokenKey $tokenKey -Method "GET" -Uri $selfUrl

if (-not $headers) {
    Write-Host "  [FAIL] HMAC signature generation failed" -ForegroundColor Red
    exit 1
}

Write-Host "  Signature: $($headers.Signature.Substring(0,20))..." -ForegroundColor Gray
Write-Host "  Sending authenticated request..."

try {
    $selfResponse = Invoke-RestMethod -Uri $selfUrl -Method GET -Headers $headers -TimeoutSec 10 -ErrorAction Stop
    
    Write-Host ""
    Write-Host "  SUCCESS!" -ForegroundColor Green
    Write-Host ""
    
    if ($selfResponse.data -and $selfResponse.data.email_address) {
        Write-Host "  Authenticated as: $($selfResponse.data.email_address)" -ForegroundColor Cyan
    }
    else {
        Write-Host "  Authenticated (but unexpected response format)" -ForegroundColor Yellow
    }
    
    Write-Host ""
    Write-Host "  API authentication is working correctly!" -ForegroundColor Green
}
catch {
    $statusCode = $null
    if ($_.Exception.Response) {
        $statusCode = $_.Exception.Response.StatusCode.value__
    }
    
    Write-Host ""
    Write-Host "  FAILED!" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
    
    if ($statusCode -eq 401) {
        Write-Host ""
        Write-Host "  401 Unauthorized - Possible causes:" -ForegroundColor Yellow
        Write-Host "    1. Invalid Token ID or Token Key" -ForegroundColor Gray
        Write-Host "    2. Token has expired or been revoked" -ForegroundColor Gray
        Write-Host "    3. Time synchronization issue" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Troubleshooting:" -ForegroundColor Yellow
        Write-Host "    - Check time sync: w32tm /query /status" -ForegroundColor Gray
        Write-Host "    - Resync time: w32tm /resync /rediscover" -ForegroundColor Gray
        Write-Host "    - Verify Token and TokenID in auth.json" -ForegroundColor Gray
        Write-Host "    - Generate new API token in BHE console" -ForegroundColor Gray
    }
    elseif ($statusCode -eq 403) {
        Write-Host ""
        Write-Host "  403 Forbidden - Valid credentials but insufficient permissions" -ForegroundColor Yellow
    }
    else {
        Write-Host ""
        Write-Host "  Unexpected error occurred (HTTP $statusCode)" -ForegroundColor Yellow
    }
    
    Write-Host ""
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Test Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
